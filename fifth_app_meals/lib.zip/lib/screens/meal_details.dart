import 'package:fifth_app_meals/models/meal.dart';
import 'package:flutter/material.dart';

class MealDetails extends StatelessWidget {
  const MealDetails({super.key, required this.meal});
  final Meal meal;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          meal.title,
          style: TextStyle(
            color: Theme.of(context).colorScheme.onPrimaryContainer,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Center(
        child: Column(
          children: [
            Text(meal.ingredients.toString(),),
            const SizedBox(height: 10,),
            Text(meal.steps.toString(),),
            const SizedBox(height: 10,),

          ],
        ),
      ),
    );
  }
}
